package trick;

import java.util.*;


public class FindTreatsRoute {

    private static void dfs(Graph neighborHoodGraph, String curr, Map<String, Boolean> visited, List<String> dfsOrder) {
        if (visited.get(curr)) {
            return;
        }
        visited.put(curr, true);
        dfsOrder.add(curr);

        for (House neighbor : neighborHoodGraph.retrieveNeighbors(curr)) {
            dfs(neighborHoodGraph, neighbor.getName(), visited, dfsOrder);
        }
    }

    public static void main(String[] args) {
        if (args.length < 3) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "Run command: java -cp bin trick.FindTreatsRoute input1.in h1 findtreats1.out");
            return;
        }
        Graph neighborhoodGraph = NeighborhoodMap.buildGraph(args[0]);
        String sourceHouse = args[1]; 

        List<String> dfsOrder = new ArrayList<>();
        Map<String, Boolean> visited = new HashMap<>();
        for (String house : neighborhoodGraph.getAdjacencyList().keySet()) {
            visited.put(house, false);
        }
        dfs(neighborhoodGraph, sourceHouse, visited, dfsOrder);

        StdOut.setFile(args[2]);
        for (String house : dfsOrder) {
            StdOut.print(house + " ");
        }
        StdOut.println();
        
    }
}
