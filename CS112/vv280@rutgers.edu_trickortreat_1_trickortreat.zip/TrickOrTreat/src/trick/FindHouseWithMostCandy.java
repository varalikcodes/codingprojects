package trick;

import java.util.*;

public class FindHouseWithMostCandy {

    private static void dfs(Graph neighborHoodGraph, String curr, Map<String, Boolean> visited, List<String> dfsOrder) {
        if (visited.get(curr)) {
            return;
        }
        visited.put(curr, true);
        dfsOrder.add(curr);

        for (House neighbor : neighborHoodGraph.retrieveNeighbors(curr)) {
            dfs(neighborHoodGraph, neighbor.getName(), visited, dfsOrder);
        }
    }

    public static void main(String[] args) {
        if (args.length < 4) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "Execute: java -cp bin trick.FindHouseWithMostCandy input1.in h1 Skittles findcandy1.out");
            return;
        }

        Graph neighborhoodGraph = NeighborhoodMap.buildGraph(args[0]);
        String sourceHouse = args[1]; 
        String candyName = args[2];

        List<String> dfsOrder = new ArrayList<>();
        Map<String, Boolean> visited = new HashMap<>();
        for (String house : neighborhoodGraph.getAdjacencyList().keySet()) {
            visited.put(house, false);
        }
        dfs(neighborhoodGraph, sourceHouse, visited, dfsOrder);

        String houseMostCandy = null;
        int max = 0;

        for (String house : dfsOrder) {
            int count = 0;
            for (Candy candy : neighborhoodGraph.getCandies(house)) {
                if (candy.getName().equals(candyName)) {
                    count += candy.getCount();
                }
            }

            if (count > max) {
                max = count;
                houseMostCandy = house;
            }
        }
        StdOut.setFile(args[3]);
        StdOut.println(houseMostCandy);
        
    }
}
