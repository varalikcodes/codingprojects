package trick;
import java.util.*;
public class House {

    private String name;
    private int weight;
    private ArrayList<Candy> candies;

    public House(String name, int weight) {
        this.name = name;
        this.weight = weight;
        this.candies = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getWeight() {
        return weight;
    }

    public ArrayList<Candy> getCandies() {
        return candies;
    }

    public void addCandy(Candy candy) {
        candies.add(candy);
    }

}
