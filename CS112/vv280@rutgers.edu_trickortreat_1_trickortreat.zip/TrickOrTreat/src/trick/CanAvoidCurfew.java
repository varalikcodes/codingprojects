package trick;

import java.util.*;

public class CanAvoidCurfew {

    public static Map<String, Integer> dijkstra(Graph graph, String source) {
    Map<String, Integer> dist = new HashMap<>();
    Set<String> visited = new HashSet<>();
    PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(dist::get));

    for (String house : graph.getAdjacencyList().keySet()) {
        dist.put(house, Integer.MAX_VALUE);
    }
    dist.put(source, 0);
    pq.add(source);

    while (!pq.isEmpty()) {
        String curr = pq.poll();

        if (visited.contains(curr)) {
            continue;
        }
        visited.add(curr);

        for (House neighbor : graph.retrieveNeighbors(curr)) {
            String neighborName = neighbor.getName();
            int edgeWeight = neighbor.getWeight();

            if (!visited.contains(neighborName)) {
                int newDist = dist.get(curr) + edgeWeight;
                if (newDist < dist.get(neighborName)) {
                    dist.put(neighborName, newDist);
                    pq.add(neighborName);
                }
            }
        }
    }

    return dist;
}
    public static void main(String[] args) {
        if (args.length < 5) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "Execute: java -cp bin trick.CanAvoidCurfew input1.in h1 h8 100 shortestpaths1.out");
            return;
        }

        Graph neighborhoodGraph = NeighborhoodMap.buildGraph(args[0]);
        String sourceHouse = args[1];
        String otherHouse = args[2];
        int curfew = Integer.parseInt(args[3]);

        Map<String, Integer> dist = dijkstra(neighborhoodGraph, sourceHouse);

        int distanceToDestination = dist.getOrDefault(otherHouse, Integer.MAX_VALUE);
        StdOut.setFile(args[4]);
        if(distanceToDestination <= curfew) {
            StdOut.println(true + " " + distanceToDestination);
        }
        else {
            StdOut.println(false + " " + distanceToDestination);
        }
  
    }
}
