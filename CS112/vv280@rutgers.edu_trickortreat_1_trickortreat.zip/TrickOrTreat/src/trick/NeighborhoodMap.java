package trick;
import java.util.*;

public class NeighborhoodMap {

    public static Graph buildGraph(String inputFile) {
        StdIn.setFile(inputFile);

        int numberOfHouses = StdIn.readInt();
        Graph neighborhoodGraph = new Graph();

        for (int i = 0; i < numberOfHouses; i++) {
            String houseName = StdIn.readString();
            neighborhoodGraph.addHouse(houseName);
            int candyCount = StdIn.readInt();
            for (int j = 0; j < candyCount; j++) {
                String candyName = StdIn.readString();
                int count = StdIn.readInt();
                Candy toAdd = new Candy(candyName, count);
                neighborhoodGraph.addCandy(houseName, toAdd);
            }
        }

        int numberOfEdges = StdIn.readInt();
        for (int i = 0; i < numberOfEdges; i++) {
            String house1 = StdIn.readString();
            String house2 = StdIn.readString();
            int weight = StdIn.readInt();
            neighborhoodGraph.addEdge(house1, house2, weight);
        }

        return neighborhoodGraph;
    }
    public static void main(String[] args) {
        if (args.length < 2) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "Execute: java -cp bin trick.NeighborhoodMap <neighborhoodmap INput file> <neighborhoodmap OUTput file>");
            return;
        }

        Graph neighborhoodGraph = buildGraph(args[0]);
        StdOut.setFile(args[1]);
        for (String houseName : neighborhoodGraph.getHouseCandies().keySet()) {
            StdOut.print(houseName);
            for (Candy candy : neighborhoodGraph.getCandies(houseName)) {
                StdOut.print(" " + candy.toString());
            }
            StdOut.println();
        }
        for (String houseName : neighborhoodGraph.getAdjacencyList().keySet()) {
            StdOut.print(houseName);
            for (House neighbor : neighborhoodGraph.retrieveNeighbors(houseName)) {
                StdOut.print(" " + neighbor.getName() + " " + neighbor.getWeight());
            }
            StdOut.println();
        }
    }
}
