package trick;

import java.util.*;


public class ShortestPath {

     public static Map<String, String> dijkstra(Graph graph, String source) {

        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> pred = new HashMap<>(); 
        Set<String> visited = new HashSet<>();
        PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(dist::get));

        for (String house : graph.getAdjacencyList().keySet()) {
            dist.put(house, Integer.MAX_VALUE);
            pred.put(house, null);
        }
        dist.put(source, 0);
        pq.add(source);

        while (!pq.isEmpty()) {
            String curr = pq.poll();

            if (visited.contains(curr))
            { 
                continue;
            }
            visited.add(curr);

            for (House neighbor : graph.retrieveNeighbors(curr)) {
                String neighborName = neighbor.getName();
                int edgeWeight = neighbor.getWeight();

                if (!visited.contains(neighborName)) {
                    int newDist = dist.get(curr) + edgeWeight;
                    if (newDist < dist.get(neighborName)) {
                        dist.put(neighborName, newDist);
                        pred.put(neighborName, curr);
                        pq.add(neighborName);
                    }
                }
            }
        }

        return pred;
    }
    public static void main(String[] args) {
        if (args.length < 3) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "Execute: java -cp bin trick.ShortestPath input1.in h1 shortestpaths1.out");
            return;
        }

        Graph neighborhoodGraph = NeighborhoodMap.buildGraph(args[0]);
        String sourceHouse = args[1];

        Map<String, String> pred = dijkstra(neighborhoodGraph, sourceHouse);

        StdOut.setFile(args[2]);
        for (Map.Entry<String, String> entry : pred.entrySet()) {
            StdOut.println(entry.getKey() + " " + (entry.getValue() == null ? "null" : entry.getValue()));
        }
        
    }
}
