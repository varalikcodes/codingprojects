package trick;
import java.util.*;
public class Graph {
    private HashMap<String, List<House>> adjacencyList;
    private HashMap<String, ArrayList<Candy>> houseCandies;

    public Graph() {
        adjacencyList = new HashMap<>();
        houseCandies = new HashMap<>();
    }

    public void addHouse(String houseName) {
        adjacencyList.putIfAbsent(houseName, new LinkedList<>());
    }

    public void addEdge(String house1, String house2, int weight) {
        addHouse(house1);
        addHouse(house2);
        adjacencyList.get(house1).add(new House(house2, weight));
        adjacencyList.get(house2).add(new House(house1, weight));
    }

    public void addCandy(String houseName, Candy candy) {
        houseCandies.putIfAbsent(houseName, new ArrayList<>());
        houseCandies.get(houseName).add(candy);
    }

    public List<House> retrieveNeighbors(String houseName) {
        return adjacencyList.getOrDefault(houseName, new LinkedList<>());
    }

    public ArrayList<Candy> getCandies(String houseName) {
        return houseCandies.getOrDefault(houseName, new ArrayList<>());
    }

    public HashMap<String, ArrayList<Candy>> getHouseCandies() {
        return houseCandies;
    }

    public HashMap<String, List<House>> getAdjacencyList () {
        return adjacencyList;
    }
}
