package trick;

import java.util.*;

public class PathToMostCandy {
    
    public static List<String> bfs(Graph neighborhoodGraph, String sourceHouse, String targetHouse) {
        Map<String, String> edgeTo = new HashMap<>();
        Queue<String> queue = new LinkedList<>();
        Map<String, Boolean> visited = new HashMap<>();

        for (String house : neighborhoodGraph.getAdjacencyList().keySet()) {
            visited.put(house, false);
        }

        queue.add(sourceHouse);
        visited.put(sourceHouse, true);
        edgeTo.put(sourceHouse, null);

        while (!queue.isEmpty()) {
            String current = queue.poll();

            if (current.equals(targetHouse)){
                break;
            }

            for (House neighbor : neighborhoodGraph.retrieveNeighbors(current)) {
                if (!visited.get(neighbor.getName())) {
                    visited.put(neighbor.getName(), true);
                    queue.add(neighbor.getName());
                    edgeTo.put(neighbor.getName(), current);
                }
            }
        }

        List<String> path = new ArrayList<>();
        for (String v = targetHouse; v != null; v = edgeTo.get(v)) {
            path.add(v);
        }
        Collections.reverse(path);
        return path;
    }
    public static void main(String[] args) {
        if (args.length < 4) {
            StdOut.println(
                    "Too few arguments. Did you put in command line arguments? If using the debugger, add args to launch.json.");
            StdOut.println(
                    "execute: java -cp bin trick.PathToMostCandy input1.in h1 KitKat mostcandy1.out");
            return;
        }

        Graph neighborhoodGraph = NeighborhoodMap.buildGraph(args[0]);
        String sourceHouse = args[1];
        String candyName = args[2];

        String houseMostCandy = null;
        int max = 0;
        for (String house : neighborhoodGraph.getHouseCandies().keySet()) {
            int count = 0;
            for (Candy candy : neighborhoodGraph.getCandies(house)) {
                if (candy.getName().equals(candyName)) {
                    count += candy.getCount();
                }
            }
            if (count > max) {
                max = count;
                houseMostCandy = house;
            }
        }
        List<String> path = bfs(neighborhoodGraph, sourceHouse, houseMostCandy);

        StdOut.setFile(args[3]);
        for (String house : path) {
            StdOut.print(house + " ");
        }
        StdOut.println();
        
    }
}
